import React, { useState } from 'react';
import styles from './Sidebar.module.css';
import { mainLinks, bottomLinks, settingLink } from '../../data/navigationLinks.jsx';

const Sidebar = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <aside className={styles.sidebar}>
      {/* Logo */}
      <div className={styles.logo}>
        Health<span>care.</span>
      </div>

      {/* General Section */}
      <div className={styles.sectionTitle}>General</div>
      <nav className={styles.mainNav}> 
        <ul className={styles.navList}>
          {mainLinks.map((link, idx) => (
            <li
              key={idx}
              className={`${styles.navItem} ${activeIndex === idx ? styles.active : ''}`}
              onClick={() => setActiveIndex(idx)} // Add onClick to change active item
            >
              <span className={styles.icon}>{link.icon}</span>
              <span>{link.label}</span>
            </li>
          ))}
        </ul>
      </nav>

      {/* Tools Section Title - Moved here */}
      <div className={`${styles.sectionTitle} ${styles.toolsTitle}`}>Tools</div> {/* Added toolsTitle class for potential spacing */}

      {/* Bottom Links (Chat, Support) */}
      <nav className={styles.bottomNav}> {/* Added class for bottom nav spacing */}
        <ul className={styles.navList}>
          {bottomLinks.map((link, idx) => (
            <li key={idx} className={styles.navItem}>
              <span className={styles.icon}>{link.icon}</span>
              <span>{link.label}</span>
            </li>
          ))}
        </ul>
      </nav>

      {/* Setting Link (at the very bottom) */}
      {/* CSS will push this to the bottom using margin-top: auto */}
      <div className={styles.settingItem}>
        <span className={styles.icon}>{settingLink.icon}</span>
        <span>{settingLink.label}</span>
      </div>
    </aside>
  );
};

export default Sidebar;
