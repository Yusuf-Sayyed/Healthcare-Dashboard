import React from 'react';
import styles from './RightColumnContainer.module.css';
import CalendarView from '../CalendarView/CalendarView';
import SimpleAppointmentCard from '../SimpleAppointmentCard/SimpleAppointmentCard';
import UpcomingSchedule from '../UpcomingSchedule/UpcomingSchedule';

const RightColumnContainer = ({ specificAppointments, upcomingScheduleData }) => {
    return (
        <div className={styles.rightColumnCard}>
            {/* Calendar */}
            <div className={styles.sectionCard}>
                <CalendarView />
            </div>

            {/* Specific Appointments */}
            <div className={styles.sectionCard}>
                <h2>Specific Appointments</h2>
                <div className={styles.specificAppointmentsRow}>
                    {specificAppointments.map((appointment, index) => (
                        <SimpleAppointmentCard
                            key={index}
                            type={appointment.type}
                            time={appointment.time}
                            doctor={appointment.doctor}
                            icon={appointment.icon}
                            color={appointment.color}
                            textColor={appointment.textColor}
                        />
                    ))}
                </div>
            </div>

            {/* Upcoming Schedule */}
            <div className={styles.sectionCard}>
                <UpcomingSchedule upcomingScheduleData={upcomingScheduleData} />
            </div>
        </div>
    );
};

export default RightColumnContainer;