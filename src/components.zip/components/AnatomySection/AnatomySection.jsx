import React from 'react';
import styles from './AnatomySection.module.css';


// Assuming anatomy.png is in the public folder
const anatomyImage = '/anatomy.png';

const AnatomySection = () => {
  return (
    <div className={styles.anatomyContainer}>
      <img src={anatomyImage} alt="Human Anatomy Illustration" className={styles.anatomyImage} />
      {/* Floating labels will be added here later */}
    </div>
  );
};

export default AnatomySection;
