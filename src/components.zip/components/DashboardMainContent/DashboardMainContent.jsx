import React from 'react';
import styles from './DashboardMainContent.module.css';
import AnatomySection from '../AnatomySection/AnatomySection';
import HealthStatusCards from '../HealthStatusCards/HealthStatusCards';
import ActivityFeed from '../ActivityFeed/ActivityFeed';
import CalendarView from '../CalendarView/CalendarView';
import UpcomingSchedule from '../UpcomingSchedule/UpcomingSchedule'; // Verify this path
import SimpleAppointmentCard from '../SimpleAppointmentCard/SimpleAppointmentCard';
import { BriefcaseMedical, Syringe, Eye, HeartPulse, Brain } from 'lucide-react';

const specificAppointments = [
  {
    type: "Dentist",
    time: "09:00-11:00",
    doctor: "Dr. Cameron Williamson",
    icon: <BriefcaseMedical size={20} color='#fff'/>,
    color: "#3366ff",
  },
  {
    type: "Physiotherapy Appointment",
    time: "11:00-12:00",
    doctor: "Dr. Kevin Djones",
    icon: <Syringe size={20} color='black'/>,
    color: "#F0F8FF",
    textColor: "black",
  },
];

const upcomingScheduleData = [
  {
    day: "Thursday",
    appointments: [
      { description: "Health checkup complete", time: "11:00 AM", icon: <Syringe size={20} color='#28C76F'/> },
      { description: "Ophthalmologist", time: "14:00 PM", icon: <Eye size={20} color='#5570F1'/> },
    ],
  },
  {
    day: "Saturday",
    appointments: [
      { description: "Cardiologist", time: "12:00 AM", icon: <HeartPulse size={20} color='#E74C3C'/> },
      { description: "Neurologist", time: "16:00 PM", icon: <Brain size={20} color='#FF9100'/> },
    ],
  },
];

const DashboardMainContent = () => {
  return (
    <div className={styles.dashboardLayout}>
      <div className={styles.leftColumnContent}>
        <div className={styles.topRow}>
          <AnatomySection />
          <div className={styles.cards}>
            <HealthStatusCards />
          </div>
        </div>
        <div className={styles.bottomRow}>
          <ActivityFeed />
        </div>
      </div>

      <div className={styles.rightColumnContent}>
        <CalendarView />
        <div className={styles.specificAppointmentsRow}>
          {specificAppointments.map((appointment, index) => (
            <SimpleAppointmentCard
              key={index}
              type={appointment.type}
              time={appointment.time}
              doctor={appointment.doctor}
              icon={appointment.icon}
              color={appointment.color}
              textColor={appointment.textColor}
            />
          ))}
        </div>
        <UpcomingSchedule upcomingScheduleData={upcomingScheduleData} />
      </div>
    </div>
  );
};

export default DashboardMainContent;